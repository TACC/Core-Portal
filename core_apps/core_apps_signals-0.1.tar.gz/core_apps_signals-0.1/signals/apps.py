from django.apps import AppConfig


class SignalsConfig(AppConfig):
    name = 'signals'
    verbose_name = 'Portal Signals'

    def ready(self):
        import signals.receivers
        import signals.signals
