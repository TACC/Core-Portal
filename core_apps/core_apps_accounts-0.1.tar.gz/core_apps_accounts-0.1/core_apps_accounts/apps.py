class AuthConfig(AppConfig):
    name = 'core_apps_accounts'
    label = 'portal_accounts'
    app_label = 'portal_accounts'
    verbose_name = 'Portal Accounts'
