from core_apps_accounts.tasks.ssh import (  # noqa: F401
    setup_pub_key,
    monitor_setup_pub_key
)
