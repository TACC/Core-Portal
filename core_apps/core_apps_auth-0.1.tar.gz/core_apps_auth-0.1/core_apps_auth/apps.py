from django.apps import AppConfig


class AuthConfig(AppConfig):
    name = 'core_apps_auth'
    label = 'auth'
    app_label = 'auth'
    verbose_name = 'Portal Authentication'
