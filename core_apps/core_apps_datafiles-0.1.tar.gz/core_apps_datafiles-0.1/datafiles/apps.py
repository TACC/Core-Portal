from django.apps import AppConfig


class DatafilesConfig(AppConfig):
    name = 'datafiles'
