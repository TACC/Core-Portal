from django.apps import AppConfig


class WorkbenchConfig(AppConfig):
    name = 'workbench'
