from django.apps import AppConfig


class SysmonConfig(AppConfig):
    name = 'system_monitor'
