from mock import patch, MagicMock
from django.test import TestCase
from django.core.management import call_command


class TestSwapReindex(TestCase):

    def setUp(self):
        self.patch_setup = patch('search.management.commands.reindex-files.setup_files_index')
        self.patch_connections = patch('search.management.commands.reindex-files.connections')
        self.patch_elasticsearch = patch('search.management.commands.reindex-files.elasticsearch')

        self.mock_setup = self.patch_setup.start()
        self.mock_connections = self.patch_connections.start()
        self.mock_elasticsearch = self.patch_elasticsearch.start()

        self.addCleanup(self.patch_setup.stop)
        self.addCleanup(self.patch_connections.stop)
        self.addCleanup(self.patch_elasticsearch.stop)

    @patch('search.management.commands.reindex-files.input')
    def test_raises_when_user_does_not_proceed(self, mock_input):
        mock_input.return_value = 'n'

        with self.assertRaises(SystemExit):
            call_command('reindex-files')

    @patch('search.management.commands.reindex-files.Index')
    @patch('search.management.commands.reindex-files.input')
    def test_raises_exception_when_no_index(self, mock_input, mock_index):
        mock_input.return_value = 'Y'

        mock_index.return_value.get_alias.return_value.keys.side_effect = Exception

        with self.assertRaises(SystemExit):
            call_command('reindex-files')

    @patch('search.management.commands.reindex-files.Index')
    @patch('search.management.commands.reindex-files.input')
    def test_performs_reindex_from_default_to_reindex(self, mock_input, mock_index):
        mock_input.return_value = 'Y'

        mock_index.return_value.get_alias.return_value.keys.side_effect = [['DEFAULT_NAME'], ['REINDEX_NAME']]

        mock_client = MagicMock()
        self.mock_elasticsearch.Elasticsearch.return_value = mock_client

        call_command('reindex-files')

        self.mock_elasticsearch.helpers.reindex.assert_called_with(mock_client, 'DEFAULT_NAME', 'REINDEX_NAME')

    @patch('search.management.commands.reindex-files.Index')
    @patch('search.management.commands.reindex-files.input')
    def test_performs_swap_with_correct_args(self, mock_input, mock_index):
        mock_input.return_value = 'Y'

        mock_index.return_value.get_alias.return_value.keys.side_effect = [['DEFAULT_NAME'], ['REINDEX_NAME']]

        call_command('reindex-files')

        mock_alias = {
            'actions': [
                {'remove': {'index': 'DEFAULT_NAME', 'alias': 'test-staging-files'}},
                {'remove': {'index': 'REINDEX_NAME', 'alias': 'test-staging-files-reindex'}},
                {'add': {'index': 'DEFAULT_NAME', 'alias': 'test-staging-files-reindex'}},
                {'add': {'index': 'REINDEX_NAME', 'alias': 'test-staging-files'}},
            ]
        }
        self.mock_elasticsearch.Elasticsearch().indices.update_aliases.assert_called_with(mock_alias)

    @patch('search.management.commands.reindex-files.Index')
    @patch('search.management.commands.reindex-files.input')
    def test_cleanup(self, mock_input, mock_index):
        mock_input.return_value = 'Y'

        mock_index.return_value.get_alias.return_value.keys.side_effect = [['DEFAULT_NAME'], ['REINDEX_NAME'], ['REINDEX_NAME']]
        opts = {'cleanup': True}

        call_command('reindex-files', **opts)

        self.assertEqual(mock_index.return_value.delete.call_count, 1)
