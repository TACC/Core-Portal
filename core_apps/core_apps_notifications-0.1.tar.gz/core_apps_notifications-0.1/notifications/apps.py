from django.apps import AppConfig


class NotificationsConfig(AppConfig):
    name = 'notifications'
    label = 'notifications'
    verbose_name = 'Portal Notifications'
    app_label = 'notifications'
