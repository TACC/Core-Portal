"""Webhooks URLs
"""
from django.conf.urls import url
from webhooks import views
from onboarding.api.webhook import SetupStepWebhookView


app_name = 'webhooks'
urlpatterns = [
    url(r'^jobs/$', views.JobsWebhookView.as_view(), name='jobs_wh_handler'),
    url(r'^interactive/$', views.InteractiveWebhookView.as_view(), name='interactive_wh_handler'),
    url(r'^onboarding/$', SetupStepWebhookView.as_view(), name='onboarding_wh_handler'),
]
