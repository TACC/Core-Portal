# default_app_config = 'portal.apps.licenses.apps.LicensesAppConfig'
