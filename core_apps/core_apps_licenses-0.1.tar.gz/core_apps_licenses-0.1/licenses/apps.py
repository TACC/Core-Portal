from django.apps import AppConfig


class LicensesAppConfig(AppConfig):
    name = 'licenses'
    label = 'portal_licenses'
    verbose_name = 'Portal Licenses'
